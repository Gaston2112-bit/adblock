package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

class AdBlockVpnService : VpnService() {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "com.example.adblock.STOP"

        private const val VPN_ADDRESS = "10.0.0.2"
        private const val VPN_DNS = "10.0.0.1"
        private const val UPSTREAM_DNS = "1.1.1.1"

        // Dominios bloqueados (también se bloquean sus subdominios)
        val BLOCKED = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "admob.com", "applovin.com", "applvn.com",
            "unityads.unity3d.com", "adcolony.com", "vungle.com",
            "startappservice.com", "inmobi.com", "chartboost.com", "ironsrc.com",
            "supersonicads.com", "mopub.com", "moatads.com", "adnxs.com",
            "criteo.com", "taboola.com", "outbrain.com", "pubmatic.com",
            "rubiconproject.com", "adsrvr.org", "smaato.net", "tapjoy.com",
            "fyber.com", "mintegral.com", "pangleglobal.com", "an.facebook.com"
        )
    }

    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newFixedThreadPool(8)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        startVpn()
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (running) return
        val fd = Builder()
            .setSession("AdBlock")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32) // solo el tráfico DNS pasa por la VPN
            .establish() ?: return
        tun = fd
        running = true
        Thread { loop(fd) }.start()
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n <= 0) continue
                val packet = buf.copyOf(n)
                pool.execute { handle(packet, output) }
            }
        } catch (e: Exception) {
            // la VPN se cerró
        } finally {
            stopVpn()
        }
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        try {
            if (p.size < 28) return
            if ((p[0].toInt() shr 4) != 4) return          // solo IPv4
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (p[9].toInt() != 17) return                  // solo UDP
            val srcPort = u16(p, ihl)
            val dstPort = u16(p, ihl + 2)
            if (dstPort != 53) return
            val dnsLen = u16(p, ihl + 4) - 8
            val dnsStart = ihl + 8
            if (dnsLen < 12 || dnsStart + dnsLen > p.size) return
            val dns = p.copyOfRange(dnsStart, dnsStart + dnsLen)

            val (name, qEnd) = parseQuestion(dns) ?: return
            val reply: ByteArray =
                if (isBlocked(name)) blockedReply(dns, qEnd) else (forward(dns) ?: return)

            val srcIp = p.copyOfRange(12, 16)
            val dstIp = p.copyOfRange(16, 20)
            val resp = buildPacket(dstIp, srcIp, 53, srcPort, reply)
            synchronized(out) { out.write(resp) }
        } catch (e: Exception) {
            // ignoramos consultas que fallan
        }
    }

    private fun u16(b: ByteArray, i: Int): Int =
        ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    private fun parseQuestion(d: ByteArray): Pair<String, Int>? {
        var pos = 12
        val sb = StringBuilder()
        while (pos < d.size) {
            val len = d[pos].toInt() and 0xFF
            if (len == 0) {
                pos++
                break
            }
            if ((len and 0xC0) != 0) return null
            if (pos + 1 + len > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, pos + 1, len, Charsets.US_ASCII))
            pos += 1 + len
        }
        val end = pos + 4
        if (end > d.size) return null
        return Pair(sb.toString().lowercase(), end)
    }

    private fun isBlocked(name: String): Boolean {
        var d = name
        while (true) {
            if (d in BLOCKED) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    // Respuesta "el dominio no existe" (NXDOMAIN)
    private fun blockedReply(d: ByteArray, qEnd: Int): ByteArray {
        val r = d.copyOf(qEnd)
        r[2] = 0x81.toByte()
        r[3] = 0x83.toByte()
        for (i in 6..11) r[i] = 0
        return r
    }

    private fun forward(q: ByteArray): ByteArray? {
        return DatagramSocket().use { s ->
            protect(s) // evita que esta consulta vuelva a entrar a la VPN
            s.soTimeout = 4000
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(UPSTREAM_DNS), 53))
            val buf = ByteArray(4096)
            val resp = DatagramPacket(buf, buf.size)
            s.receive(resp)
            buf.copyOf(resp.length)
        }
    }

    private fun buildPacket(
        src: ByteArray, dst: ByteArray, sp: Int, dp: Int, payload: ByteArray
    ): ByteArray {
        val total = 20 + 8 + payload.size
        val b = ByteArray(total)
        b[0] = 0x45.toByte()
        b[2] = (total shr 8).toByte()
        b[3] = total.toByte()
        b[8] = 64
        b[9] = 17
        System.arraycopy(src, 0, b, 12, 4)
        System.arraycopy(dst, 0, b, 16, 4)

        var sum = 0
        for (i in 0 until 20 step 2) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val c = sum.inv() and 0xFFFF
        b[10] = (c shr 8).toByte()
        b[11] = c.toByte()

        val udpLen = 8 + payload.size
        b[20] = (sp shr 8).toByte(); b[21] = sp.toByte()
        b[22] = (dp shr 8).toByte(); b[23] = dp.toByte()
        b[24] = (udpLen shr 8).toByte(); b[25] = udpLen.toByte()
        System.arraycopy(payload, 0, b, 28, payload.size)
        return b
    }

    private fun stopVpn() {
        running = false
        try {
            tun?.close()
        } catch (e: Exception) {
        }
        tun = null
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }
}
