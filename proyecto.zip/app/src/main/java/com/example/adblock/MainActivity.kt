package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var button: Button

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startService(Intent(this, AdBlockVpnService::class.java))
            }
            refreshLater()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
        }
        button = Button(this)
        button.setOnClickListener { toggle() }

        layout.addView(status)
        layout.addView(button)
        setContentView(layout)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toggle() {
        if (AdBlockVpnService.running) {
            val stop = Intent(this, AdBlockVpnService::class.java)
            stop.action = AdBlockVpnService.ACTION_STOP
            startService(stop)
            refreshLater()
        } else {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                vpnPermission.launch(intent)
            } else {
                startService(Intent(this, AdBlockVpnService::class.java))
                refreshLater()
            }
        }
    }

    private fun refreshLater() {
        button.postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        if (AdBlockVpnService.running) {
            status.text = "Bloqueo de anuncios ACTIVADO"
            button.text = "Desactivar"
        } else {
            status.text = "Bloqueo de anuncios DESACTIVADO"
            button.text = "Activar"
        }
    }
}
